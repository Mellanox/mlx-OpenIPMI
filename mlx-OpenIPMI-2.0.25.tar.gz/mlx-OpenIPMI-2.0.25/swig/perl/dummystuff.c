/*
 * Supply some dummy functions that are needed for linking but not
 * used.
 */

#include <OpenIPMI/ipmi_cmdlang.h>

void ipmi_cmdlang_report_event(ipmi_cmdlang_event_t *event)
{
}
